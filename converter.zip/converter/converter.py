from io import BytesIO
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
from PyPDF4 import PdfFileReader, PdfFileWriter
from django import urls
from docx import Document
from reportlab.pdfgen import canvas
import pandas as pd
import pypandoc
from email import policy
from email.parser import BytesParser
from bs4 import BeautifulSoup
import pdfkit
from PIL import Image
from pdf2image import convert_from_path
import fitz  # PyMuPDF
from docx2pdf import convert as docx2pdf_convert
from pdf2docx import Converter as pdf2docx_Converter
import subprocess
import os
from PIL import Image, ImageTk


def convert():
    pass

class PDFEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Converter")
        self.center_window(self.root, 400, 400)
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.root, padx=20, pady=20)
        self.frame.pack(expand=True, fill=tk.BOTH)
        self.inner_frame = tk.Frame(self.frame)
        self.inner_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Button(self.inner_frame, text="PDF Düzenleyici", command=self.open_pdf_editor).pack(pady=10)
        tk.Button(self.inner_frame, text="Ses Dönüştürücü", command=self.open_audio_converter).pack(pady=10)
        tk.Button(self.inner_frame, text="Dosya Dönüştürücü", command=self.open_file_converter).pack(pady=10)

    def open_pdf_editor(self):
        self.new_window = tk.Toplevel(self.root)
        self.app = PDFEditorWindow(self.new_window)

    def open_audio_converter(self):
        self.new_window = tk.Toplevel(self.root)
        self.app = AudioConverterWindow(self.new_window)

    def open_file_converter(self):
        self.new_window = tk.Toplevel(self.root)
        self.app = FileConverterWindow(self.new_window)

    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        position_top = int(screen_height / 2 - height / 2)
        position_left = int(screen_width / 2 - width / 2)
        window.geometry(f'{width}x{height}+{position_left}+{position_top}')

class PDFEditorWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("PDF Düzenleyici")
        self.center_window(self.root, 400, 400)
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.root)
        self.frame.pack(expand=True)

        self.select_button = tk.Button(self.frame, text="PDF Seçiniz", command=self.select_pdf)
        self.select_button.grid(row=0, column=0, padx=5, pady=10)

        self.file_entry = tk.Entry(self.frame, width=30)
        self.file_entry.grid(row=0, column=1, padx=5, pady=10)

        self.split_button = tk.Button(self.frame, text="PDF Parçalayıcı", command=self.split_pdf)
        self.split_button.grid(row=1, column=0, columnspan=2, pady=10)

        self.add_pdf_button = tk.Button(self.frame, text="PDF Birleştirici", command=self.add_pdfs)
        self.add_pdf_button.grid(row=2, column=0, columnspan=2, pady=10)

    def select_pdf(self):
        self.selected_file = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
        self.file_entry.delete(0, tk.END)
        self.file_entry.insert(0, self.selected_file)

    def split_pdf(self):
        if not hasattr(self, 'selected_file'):
            messagebox.showerror("Error", "No file selected!")
            return

        page_numbers_str = simpledialog.askstring("Input", "Enter page numbers or ranges to split (e.g., 1-3,5,7-9):")
        if not page_numbers_str:
            messagebox.showerror("Error", "No page numbers provided!")
            return

        page_numbers = self.parse_page_ranges(page_numbers_str)
        if not page_numbers:
            messagebox.showerror("Error", "Invalid page numbers provided!")
            return

        pdf_reader = PdfFileReader(self.selected_file)
        pdf_writer = PdfFileWriter()

        for page_num in page_numbers:
            if page_num < len(pdf_reader.pages):
                pdf_writer.addPage(pdf_reader.getPage(page_num))
            else:
                messagebox.showerror("Error", f"Page number {page_num + 1} is out of range!")

        output_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
        if output_path:
            with open(output_path, 'wb') as output_file:
                pdf_writer.write(output_file)
            messagebox.showinfo("Success", f"Split PDF saved as: {output_path}")
        else:
            messagebox.showerror("Error", "No output file selected!")

    def parse_page_ranges(self, page_ranges):
        page_numbers = []
        try:
            for part in page_ranges.split(','):
                if '-' in part:
                    start, end = part.split('-')
                    page_numbers.extend(range(int(start) - 1, int(end)))  # 1-index'den 0-index'e dönüşüm
                else:
                    page_numbers.append(int(part) - 1)  # 1-index'den 0-index'e dönüşüm
        except ValueError:
            return None
        return page_numbers

    def add_pdfs(self):
        pdf_files_to_add = filedialog.askopenfilenames(
            title="Select PDF files to add",
            filetypes=[("PDF files", "*.pdf")],
            initialdir=".",
            multiple=True
        )

        if not pdf_files_to_add:
            messagebox.showerror("Error", "No files selected!")
            return

        pdf_writer = PdfFileWriter()

        if hasattr(self, 'selected_file') and self.selected_file:
            pdf_reader_to_add = PdfFileReader(self.selected_file)
            for page_num in range(pdf_reader_to_add.numPages):
                pdf_writer.addPage(pdf_reader_to_add.getPage(page_num))

        for pdf_path in pdf_files_to_add:
            try:
                pdf_reader_to_add = PdfFileReader(pdf_path)
                for page_num in range(pdf_reader_to_add.numPages):
                    pdf_writer.addPage(pdf_reader_to_add.getPage(page_num))
            except Exception as e:
                messagebox.showerror("Error", f"Error reading {pdf_path}: {e}")

        output_path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            title="Save PDF with added pages as"
        )

        if output_path:
            try:
                with open(output_path, 'wb') as output_file:
                    pdf_writer.write(output_file)
                messagebox.showinfo("Success", f"PDF with added pages saved as: {output_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Error saving PDF: {e}")
        else:
            messagebox.showerror("Error", "No output file selected!")

    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        position_top = int(screen_height / 2 - height / 2)
        position_left = int(screen_width / 2 - width / 2)
        window.geometry(f'{width}x{height}+{position_left}+{position_top}')

class AudioConverterWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Ses Dönüştürücü")
        self.center_window(self.root, 400, 400)
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.root)
        self.frame.pack(expand=True)

        tk.Label(self.frame, text="Giriş Ses Dosyası:").grid(row=0, column=0, padx=10, pady=5, sticky=tk.W)
        self.input_entry = tk.Entry(self.frame, width=30)
        self.input_entry.grid(row=0, column=1, padx=10, pady=5)
        tk.Button(self.frame, text="Seçiniz", command=self.select_input_file).grid(row=0, column=2, padx=10, pady=5)

        tk.Label(self.frame, text="Çıkış Dosyası Yolu:").grid(row=1, column=0, padx=10, pady=5, sticky=tk.W)
        self.output_entry = tk.Entry(self.frame, width=30)
        self.output_entry.grid(row=1, column=1, padx=10, pady=5)
        tk.Button(self.frame, text="Seçiniz", command=self.select_output_directory).grid(row=1, column=2, padx=10, pady=5)

        tk.Label(self.frame, text="Giriş Formatı:").grid(row=2, column=0, padx=10, pady=5, sticky=tk.W)
        self.input_format_combobox = ttk.Combobox(self.frame, values=['wav', 'mp3', 'aac','mp4'])
        self.input_format_combobox.grid(row=2, column=1, padx=10, pady=5)
        self.input_format_combobox.set('')  # Default value

        tk.Label(self.frame, text="Çıkış Formatı:").grid(row=3, column=0, padx=10, pady=5, sticky=tk.W)
        self.output_format_combobox = ttk.Combobox(self.frame, values=['wav', 'mp3', 'aac','mp4'])
        self.output_format_combobox.grid(row=3, column=1, padx=10, pady=5)
        self.output_format_combobox.set('')  # Default value

        tk.Button(self.frame, text="Dönüştür", command=self.convert_audio).grid(row=4, column=0, columnspan=3, pady=10)

    def select_input_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Audio files", "*.wav;*.mp3;*.aac;*.mp4")])
        if file_path:
            self.input_entry.delete(0, tk.END)
            self.input_entry.insert(0, file_path)

    def select_output_directory(self):
        directory = filedialog.askdirectory()
        if directory:
            self.output_entry.delete(0, tk.END)
            self.output_entry.insert(0, directory)

    def convert_audio(self):
        input_file = self.input_entry.get()
        output_dir = self.output_entry.get()
        input_format = self.input_format_combobox.get()
        output_format = self.output_format_combobox.get()

        if not input_file or not output_dir:
            messagebox.showerror("Error", "Please select input file and output directory.")
            return

        output_file = os.path.join(output_dir, f"converted.{output_format}")

        try:
            # Convert audio format using ffmpeg
            subprocess.run(['ffmpeg', '-i', input_file, output_file], check=True)
            messagebox.showinfo("Success", f"Audio file converted successfully and saved to {output_file}")
        except subprocess.CalledProcessError:
            messagebox.showerror("Error", "Failed to convert audio file.")

    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        position_top = int(screen_height / 2 - height / 2)
        position_left = int(screen_width / 2 - width / 2)
        window.geometry(f'{width}x{height}+{position_left}+{position_top}')

def word_to_pdf(input_path, output_path):
    docx2pdf_convert(input_path, output_path)

def pdf_to_jpeg(input_path, output_path):
    pages = convert_from_path(input_path)
    for i, page in enumerate(pages):
        page.save(f"{output_path}_page_{i+1}.jpeg", 'JPEG')

def jpeg_to_pdf(input_path, output_path):
    image = Image.open(input_path)
    pdf_bytes = BytesIO()
    image.save(pdf_bytes, format='PDF')
    with open(output_path, 'wb') as f:
        f.write(pdf_bytes.getvalue())

def pdf_to_word(input_path, output_path):
    pdf2docx_Converter(input_path, output_path).convert()

def word_to_jpeg(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("Word to JPEG conversion is not implemented")

def csv_to_xlsx(input_path, output_path):
    df = pd.read_csv(input_path)
    df.to_excel(output_path, index=False)

def xlsx_to_csv(input_path, output_path):
    df = pd.read_excel(input_path)
    df.to_csv(output_path, index=False)

def rtf_to_txt(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("RTF to TXT conversion is not implemented")

def rtf_to_pdf(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("RTF to PDF conversion is not implemented")

def html_to_pdf(input_path, output_path):
    pdfkit.from_file(input_path, output_path)

def odt_to_pdf(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("ODT to PDF conversion is not implemented")

def epub_to_pdf(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("EPUB to PDF conversion is not implemented")

def msg_to_txt(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("MSG to TXT conversion is not implemented")

def msg_to_pdf(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("MSG to PDF conversion is not implemented")

def pub_to_pdf(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("PUB to PDF conversion is not implemented")

def xml_to_txt(input_path, output_path):
    with open(input_path, 'r') as xml_file:
        soup = BeautifulSoup(xml_file, 'xml')
        with open(output_path, 'w') as txt_file:
            txt_file.write(soup.get_text())

def xml_to_pdf(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("XML to PDF conversion is not implemented")

def eml_to_txt(input_path, output_path):
    with open(input_path, 'r') as eml_file:
        msg = BytesParser(policy=policy.default).parse(eml_file)
        with open(output_path, 'w') as txt_file:
            txt_file.write(msg.get_payload(decode=True).decode())

def eml_to_pdf(input_path, output_path):
    # Requires additional libraries for conversion
    # This is a placeholder
    raise NotImplementedError("EML to PDF conversion is not implemented")

class FileConverterWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Dosya Dönüştürücü")
        self.center_window(self.root, 400, 400)
        self.root.resizable(False, False)  # Sayfa boyutunu sabit tut
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.root, padx=20, pady=20)
        self.frame.pack(expand=True, fill=tk.BOTH)

        # İç çerçeve, butonları ortalamak için kullanılıyor
        self.inner_frame = tk.Frame(self.frame)
        self.inner_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.inner_frame, text="Giriş Dosyası:").grid(row=0, column=0, padx=10, pady=5, sticky=tk.W)
        self.input_entry = tk.Entry(self.inner_frame, width=30)
        self.input_entry.grid(row=0, column=1, padx=10, pady=5)
        tk.Button(self.inner_frame, text="Seçiniz", command=self.select_input_file).grid(row=0, column=2, padx=10, pady=5)

        tk.Label(self.inner_frame, text="Çıkış Dosyası Yolu:").grid(row=1, column=0, padx=10, pady=5, sticky=tk.W)
        self.output_entry = tk.Entry(self.inner_frame, width=30)
        self.output_entry.grid(row=1, column=1, padx=10, pady=5)
        tk.Button(self.inner_frame, text="Seçiniz", command=self.select_output_directory).grid(row=1, column=2, padx=10, pady=5)

        tk.Label(self.inner_frame, text="Giriş Formatı:").grid(row=2, column=0, padx=10, pady=5, sticky=tk.W)
        self.input_format_combobox = ttk.Combobox(self.inner_frame, values=['docx', 'html', 'md', 'pdf', 'jpeg', 'csv', 'xlsx', 'rtf', 'odt', 'epub', 'msg', 'pub', 'xml', 'eml'])
        self.input_format_combobox.grid(row=2, column=1, padx=10, pady=5)
        self.input_format_combobox.set('')  # Default value

        tk.Label(self.inner_frame, text="Çıkış Formatı:").grid(row=3, column=0, padx=10, pady=5, sticky=tk.W)
        self.output_format_combobox = ttk.Combobox(self.inner_frame, values=['pdf', 'docx', 'jpeg', 'txt', 'xlsx', 'csv'])
        self.output_format_combobox.grid(row=3, column=1, padx=10, pady=5)
        self.output_format_combobox.set('')  # Default value

        tk.Button(self.inner_frame, text="Dönüştür", command=self.convert_file).grid(row=4, column=0, columnspan=3, pady=10)

    def select_input_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("All files", "*.*")])
        if file_path:
            self.input_entry.delete(0, tk.END)
            self.input_entry.insert(0, file_path)

    def select_output_directory(self):
        directory = filedialog.askdirectory()
        if directory:
            self.output_entry.delete(0, tk.END)
            self.output_entry.insert(0, directory)

    def convert_file(self):
        input_file = self.input_entry.get()
        output_dir = self.output_entry.get()
        input_format = self.input_format_combobox.get()
        output_format = self.output_format_combobox.get()

        if not input_file or not output_dir:
            messagebox.showerror("Error", "Lütfen giriş dosyasını ve çıkış dizinini seçin.")
            return

        output_file = os.path.join(output_dir, f"converted.{output_format}")

        try:
            if input_format == 'docx' and output_format == 'pdf':
                word_to_pdf(input_file, output_file)
            elif input_format == 'pdf' and output_format == 'jpeg':
                pdf_to_jpeg(input_file, output_file)
            elif input_format == 'jpeg' and output_format == 'pdf':
                jpeg_to_pdf(input_file, output_file)
            elif input_format == 'pdf' and output_format == 'docx':
                pdf_to_word(input_file, output_file)
            elif input_format == 'docx' and output_format == 'jpeg':
                word_to_jpeg(input_file, output_file)
            elif input_format == 'csv' and output_format == 'xlsx':
                csv_to_xlsx(input_file, output_file)
            elif input_format == 'xlsx' and output_format == 'csv':
                xlsx_to_csv(input_file, output_file)
            elif input_format == 'rtf' and output_format == 'txt':
                rtf_to_txt(input_file, output_file)
            elif input_format == 'rtf' and output_format == 'pdf':
                rtf_to_pdf(input_file, output_file)
            elif input_format == 'html' and output_format == 'pdf':
                html_to_pdf(input_file, output_file)
            elif input_format == 'odt' and output_format == 'pdf':
                odt_to_pdf(input_file, output_file)
            elif input_format == 'epub' and output_format == 'pdf':
                epub_to_pdf(input_file, output_file)
            elif input_format == 'msg' and output_format == 'txt':
                msg_to_txt(input_file, output_file)
            elif input_format == 'msg' and output_format == 'pdf':
                msg_to_pdf(input_file, output_file)
            elif input_format == 'pub' and output_format == 'pdf':
                pub_to_pdf(input_file, output_file)
            elif input_format == 'xml' and output_format == 'txt':
                xml_to_txt(input_file, output_file)
            elif input_format == 'xml' and output_format == 'pdf':
                xml_to_pdf(input_file, output_file)
            elif input_format == 'eml' and output_format == 'txt':
                eml_to_txt(input_file, output_file)
            elif input_format == 'eml' and output_format == 'pdf':
                eml_to_pdf(input_file, output_file)
            else:
                messagebox.showerror("Error", "Desteklenmeyen format kombinasyonu.")
                return

            messagebox.showinfo("Success", f"Dosya başarıyla dönüştürüldü ve {output_file} konumuna kaydedildi")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        position_top = int(screen_height / 2 - height / 2)
        position_left = int(screen_width / 2 - width / 2)
        window.geometry(f'{width}x{height}+{position_left}+{position_top}')

def open_pdf_editor_window():
    root = tk.Toplevel()
    app = PDFEditor(root)
    root.wait_window()

def open_file_converter_window():
    root = tk.Toplevel()
    app = FileConverterWindow(root)
    root.wait_window()  

def open_pdf_editor_window_2():
    root = tk.Toplevel()
    app = PDFEditorWindow(root)
    root.wait_window()

def open_audio_converter_window():
    root = tk.Toplevel()
    app = AudioConverterWindow(root)
    root.wait_window()

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()  # Ana pencereyi gizle
    
    open_pdf_editor_window()
    root.mainloop()
