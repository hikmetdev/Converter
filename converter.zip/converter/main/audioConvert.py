import tkinter as tk
from tkinter import filedialog, ttk, messagebox
from pydub import AudioSegment

class AudioConverterApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ses Dosyası Dönüştürücü")
        self.root.geometry("400x400")
        self.root.resizable(False, False)
        self.center_window()

        self.file_path = ""

        self.create_widgets()


    def center_window(self):
        window_width = 400
        window_height = 400
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width // 2) - (window_width // 2)
        y = (screen_height // 2) - (window_height // 2)
        self.root.geometry(f'{window_width}x{window_height}+{x}+{y}')


    def create_widgets(self):
        # Ana çerçeve
        self.main_frame = tk.Frame(self.root)
        self.main_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        # Başlık
        self.title_label = tk.Label(self.main_frame, text="Ses Dosyası Dönüştürücü", font=("Helvetica", 16, "bold"))
        self.title_label.pack(pady=20)

        # Dosya seçme butonu
        self.select_button = tk.Button(self.main_frame, text="Ses Dosyasını Seç", command=self.select_file, width=20)
        self.select_button.pack(pady=10)

        # Seçilen dosyanın yolunu gösteren etiket
        self.file_label = tk.Label(self.main_frame, text="Seçilen dosya: Yok", wraplength=300)
        self.file_label.pack(pady=5)

        # Format seçme menüsü
        self.format_frame = tk.Frame(self.main_frame)
        self.format_frame.pack(pady=10)

        self.format_label = tk.Label(self.format_frame, text="Hedef Formatı Seç:", font=("Helvetica", 12))
        self.format_label.grid(row=0, column=0, padx=5)

        self.format_var = tk.StringVar()
        self.format_menu = ttk.Combobox(self.format_frame, textvariable=self.format_var, values=["mp3", "wav", "flac", "ogg", "aac"], state="readonly")
        self.format_menu.grid(row=0, column=1, padx=5)

        # Dönüştürme butonu
        self.convert_button = tk.Button(self.main_frame, text="Dönüştür", command=self.convert_audio, width=20, bg="lightblue")
        self.convert_button.pack(pady=20)

    def select_file(self):
        self.file_path = filedialog.askopenfilename(filetypes=[("Ses Dosyaları", "*.wav *.mp3 *.flac *.ogg *.aac")])
        self.file_label.config(text=f"Seçilen dosya: {self.file_path if self.file_path else 'Yok'}")

    def convert_audio(self):
        if not self.file_path:
            messagebox.showerror("Hata", "Lütfen bir ses dosyası seçin.")
            return

        if not self.format_var.get():
            messagebox.showerror("Hata", "Lütfen bir hedef format seçin.")
            return

        input_path = self.file_path
        output_format = self.format_var.get()
        output_path = filedialog.asksaveasfilename(defaultextension=f".{output_format}", filetypes=[(f"{output_format.upper()} Dosyası", f"*.{output_format}")])

        if not output_path:
            messagebox.showerror("Hata", "Lütfen bir çıkış dosyası adı girin.")
            return

        try:
            audio = AudioSegment.from_file(input_path)
            audio.export(output_path, format=output_format)
            messagebox.showinfo("Başarılı", f"Dosya başarıyla {output_format} formatına dönüştürüldü.")
        except Exception as e:
            messagebox.showerror("Hata", f"Ses dosyası dönüştürülürken bir hata oluştu: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = AudioConverterApp(root)
    root.mainloop()
