import os
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from docx import Document
from reportlab.pdfgen import canvas
import pandas as pd
import pypandoc
from email import policy
from email.parser import BytesParser
from bs4 import BeautifulSoup
import pdfkit
from PIL import Image
from pdf2image import convert_from_path
import fitz  # PyMuPDF
from docx2pdf import convert as docx2pdf_convert
from pdf2docx import Converter as pdf2docx_Converter


def pdf_to_jpeg(pdf_path, jpeg_path):
    images = convert_from_path(pdf_path)
    for i, image in enumerate(images):
        image.save(f"{jpeg_path}_{i+1}.jpeg")

def jpeg_to_pdf(jpeg_path, pdf_path):
    image = Image.open(jpeg_path)
    pdf_bytes = image.convert('RGB').save(pdf_path, "PDF")

def word_to_pdf(docx_path, pdf_path):
    docx2pdf_convert(docx_path, pdf_path)

def pdf_to_word(pdf_path, docx_path):
    converter = pdf2docx_Converter(pdf_path)
    converter.convert(docx_path, start=0, end=None)
    converter.close()

def word_to_jpeg(docx_path, jpeg_path):
    # Convert Word to PDF first
    pdf_path = 'temp.pdf'
    docx2pdf_convert(docx_path, pdf_path)
    # Then convert PDF to JPEG
    pdf_to_jpeg(pdf_path, jpeg_path)
    os.remove(pdf_path)  # Clean up temporary PDF

def docx_to_pdf(docx_path, pdf_path):
    doc = Document(docx_path)
    pdf = canvas.Canvas(pdf_path)
    for para in doc.paragraphs:
        pdf.drawString(10, 800, para.text)
        pdf.showPage()
    pdf.save()

def csv_to_xlsx(csv_path, xlsx_path):
    df = pd.read_csv(csv_path)
    df.to_excel(xlsx_path, index=False)

def xlsx_to_csv(xlsx_path, csv_path):
    df = pd.read_excel(xlsx_path)
    df.to_csv(csv_path, index=False)

def rtf_to_txt(rtf_path, txt_path):
    # Use pypandoc to convert RTF to TXT
    output = pypandoc.convert_file(rtf_path, 'plain')
    with open(txt_path, 'w') as f:
        f.write(output)

def rtf_to_pdf(rtf_path, pdf_path):
    # Convert RTF to PDF using pypandoc
    pypandoc.convert_file(rtf_path, 'pdf', outputfile=pdf_path)

def html_to_pdf(html_path, pdf_path):
    pdfkit.from_file(html_path, pdf_path)

def odt_to_pdf(odt_path, pdf_path):
    pypandoc.convert_file(odt_path, 'pdf', outputfile=pdf_path)

def epub_to_pdf(epub_path, pdf_path):
    pypandoc.convert_file(epub_path, 'pdf', outputfile=pdf_path)

def msg_to_txt(msg_path, txt_path):
    with open(msg_path, 'r') as file:
        msg_content = file.read()
    with open(txt_path, 'w') as file:
        file.write(msg_content)

def msg_to_pdf(msg_path, pdf_path):
    msg_to_txt(msg_path, 'temp.txt')
    with open('temp.txt', 'r') as file:
        msg_content = file.read()
    pdf = canvas.Canvas(pdf_path)
    pdf.drawString(10, 800, msg_content)
    pdf.save()

def pub_to_pdf(pub_path, pdf_path):
    pypandoc.convert_file(pub_path, 'pdf', outputfile=pdf_path)

def xml_to_txt(xml_path, txt_path):
    with open(xml_path, 'r') as file:
        xml_content = file.read()
    with open(txt_path, 'w') as file:
        file.write(xml_content)

def xml_to_pdf(xml_path, pdf_path):
    xml_to_txt(xml_path, 'temp.txt')
    with open('temp.txt', 'r') as file:
        xml_content = file.read()
    pdf = canvas.Canvas(pdf_path)
    pdf.drawString(10, 800, xml_content)
    pdf.save()

def eml_to_txt(eml_path, txt_path):
    with open(eml_path, 'rb') as file:
        msg = BytesParser(policy=policy.default).parse(file)
    with open(txt_path, 'w') as file:
        file.write(msg.get_payload())

def eml_to_pdf(eml_path, pdf_path):
    eml_to_txt(eml_path, 'temp.txt')
    with open('temp.txt', 'r') as file:
        eml_content = file.read()
    pdf = canvas.Canvas(pdf_path)
    pdf.drawString(10, 800, eml_content)
    pdf.save()

def convert_file(input_path, output_path, input_format, output_format):
    input_ext = os.path.splitext(input_path)[1].lower()
    output_ext = f".{output_format}"
    
    # Adjust the output path with the new extension
    output_path = os.path.splitext(input_path)[0] + output_ext

    if input_format == 'docx' and output_format == 'pdf':
        word_to_pdf(input_path, output_path)
    elif input_format == 'pdf' and output_format == 'jpeg':
        pdf_to_jpeg(input_path, output_path)
    elif input_format == 'jpeg' and output_format == 'pdf':
        jpeg_to_pdf(input_path, output_path)
    elif input_format == 'pdf' and output_format == 'docx':
        pdf_to_word(input_path, output_path)
    elif input_format == 'docx' and output_format == 'jpeg':
        word_to_jpeg(input_path, output_path)
    elif input_format == 'csv' and output_format == 'xlsx':
        csv_to_xlsx(input_path, output_path)
    elif input_format == 'xlsx' and output_format == 'csv':
        xlsx_to_csv(input_path, output_path)
    elif input_format == 'rtf' and output_format == 'txt':
        rtf_to_txt(input_path, output_path)
    elif input_format == 'rtf' and output_format == 'pdf':
        rtf_to_pdf(input_path, output_path)
    elif input_format == 'html' and output_format == 'pdf':
        html_to_pdf(input_path, output_path)
    elif input_format == 'odt' and output_format == 'pdf':
        odt_to_pdf(input_path, output_path)
    elif input_format == 'epub' and output_format == 'pdf':
        epub_to_pdf(input_path, output_path)
    elif input_format == 'msg' and output_format == 'txt':
        msg_to_txt(input_path, output_path)
    elif input_format == 'msg' and output_format == 'pdf':
        msg_to_pdf(input_path, output_path)
    elif input_format == 'pub' and output_format == 'pdf':
        pub_to_pdf(input_path, output_path)
    elif input_format == 'xml' and output_format == 'txt':
        xml_to_txt(input_path, output_path)
    elif input_format == 'xml' and output_format == 'pdf':
        xml_to_pdf(input_path, output_path)
    elif input_format == 'eml' and output_format == 'txt':
        eml_to_txt(input_path, output_path)
    elif input_format == 'eml' and output_format == 'pdf':
        eml_to_pdf(input_path, output_path)
    else:
        raise ValueError(f"Unsupported conversion: {input_format} to {output_format}")

def select_input_file():
    file_path = filedialog.askopenfilename()
    input_entry.delete(0, tk.END)
    input_entry.insert(0, file_path)

def select_output_directory():
    directory_path = filedialog.askdirectory()
    if directory_path:
        input_path = input_entry.get()
        if not input_path:
            messagebox.showerror("Error", "Lütfen önce giriş dosyasını seçiniz.")
            return
        
        input_format = input_format_combobox.get()
        output_format = output_format_combobox.get()
        base_name = os.path.basename(input_path)
        output_name = os.path.splitext(base_name)[0] + f".{output_format}"
        output_path = os.path.join(directory_path, output_name)
        
        output_entry.delete(0, tk.END)
        output_entry.insert(0, directory_path)


def convert():
    input_path = input_entry.get()
    output_path = output_entry.get()
    input_format = input_format_combobox.get()
    output_format = output_format_combobox.get()

    if not input_path or not output_path:
        messagebox.showerror("Error", "Lütfen giriş dosyasını ve çıkış yolunu seçiniz.")
        return

    try:
        convert_file(input_path, output_path, input_format, output_format)
        messagebox.showinfo("Success", "Dosya başarıyla dönüştürüldü!")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Create the main window
root = tk.Tk()
root.title("Dosya Dönüştürücü")

# Create and place widgets
frame = tk.Frame(root, padx=20, pady=20)
frame.pack(expand=True, fill=tk.BOTH)

# Widgets for file input
tk.Label(frame, text="Giriş Dosyası:").grid(row=0, column=0, padx=10, pady=5, sticky=tk.W)
input_entry = tk.Entry(frame, width=50)
input_entry.grid(row=0, column=1, padx=10, pady=5)
tk.Button(frame, text="Giriş Dosyası Seçiniz", command=select_input_file).grid(row=0, column=2, padx=10, pady=5)

# Widgets for output directory
tk.Label(frame, text="Çıkış Dosya Yolu:").grid(row=1, column=0, padx=10, pady=5, sticky=tk.W)
output_entry = tk.Entry(frame, width=50)
output_entry.grid(row=1, column=1, padx=10, pady=5)
tk.Button(frame, text="Çıkış Dosya Yolu Seçiniz", command=select_output_directory).grid(row=1, column=2, padx=10, pady=5)

# Widgets for input and output formats
tk.Label(frame, text="Giriş Dosyası Formatı:").grid(row=2, column=0, padx=10, pady=5, sticky=tk.W)
input_format_combobox = ttk.Combobox(frame, values=['docx', 'csv', 'xlsx', 'rtf', 'html', 'odt', 'epub', 'msg', 'pub', 'xml', 'eml', 'pdf', 'jpeg'])
input_format_combobox.grid(row=2, column=1, padx=10, pady=5)
input_format_combobox.set('docx')  # Default value

tk.Label(frame, text="Çıkış Dosyası Formatı:").grid(row=3, column=0, padx=10, pady=5, sticky=tk.W)
output_format_combobox = ttk.Combobox(frame, values=['pdf', 'xlsx', 'csv', 'txt', 'jpeg', 'docx'])
output_format_combobox.grid(row=3, column=1, padx=10, pady=5)
output_format_combobox.set('pdf')  # Default value

# Convert button
tk.Button(frame, text="Dönüştür", command=convert).grid(row=4, column=0, columnspan=3, pady=10)

# Center the window on the screen
root.update_idletasks()
width = root.winfo_width()
height = root.winfo_height()
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width - width) // 2
y = (screen_height - height) // 2
root.geometry(f'{width}x{height}+{x}+{y}')

# Start the Tkinter event loop
root.mainloop()
