import tkinter as tk
from tkinter import messagebox
import subprocess
import os

# Belirli bir dizin belirleyin
scripts_dir = os.path.join(os.getcwd(), 'converter')

def run_script(script_name):
    script_path = os.path.join(scripts_dir, script_name)
    if os.path.isfile(script_path):
        try:
            subprocess.run(["python", script_path], check=True)
        except subprocess.CalledProcessError as e:
            messagebox.showerror("Error", f"Failed to run {script_name}: {e}")
    else:
        messagebox.showerror("Error", f"{script_name} file not found in {scripts_dir}")

def run_audio_converter():
    run_script("audioConvert.py")

def run_file_converter():
    run_script("fileConvert.py")

def run_pdf_editor():
    run_script("pdfEditor.py")

# Create the main window
root = tk.Tk()
root.title("Ana Menü")

# Create and place widgets
frame = tk.Frame(root, padx=20, pady=20)
frame.pack(expand=True, fill=tk.BOTH)

tk.Label(frame, text="Dönüştürücü Programına Hoşgeldiniz").grid(row=0, column=0, columnspan=3, pady=10)

tk.Button(frame, text="Ses Dönüştürücü", command=run_audio_converter).grid(row=1, column=0, padx=10, pady=10)
tk.Button(frame, text="Dosya Dönüştürücü", command=run_file_converter).grid(row=1, column=1, padx=10, pady=10)
tk.Button(frame, text="PDF Düzenleyici", command=run_pdf_editor).grid(row=1, column=2, padx=10, pady=10)

# Center the window on the screen
root.update_idletasks()
width = root.winfo_width()
height = root.winfo_height()
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width - width) // 2
y = (screen_height - height) // 2
root.geometry(f'{width}x{height}+{x}+{y}')

# Start the Tkinter event loop
root.mainloop()
