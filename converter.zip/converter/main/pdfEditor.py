import tkinter as tk
from tkinter import filedialog
from tkinter import simpledialog
from PyPDF4 import PdfFileReader, PdfFileWriter

class PDFEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("PDF Düzenleyici")

        # Pencere boyutunu ayarla
        window_width = 300
        window_height = 300

        # Ekran boyutlarını al
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Ekranın ortasında olacak şekilde pencerenin konumunu hesapla
        position_top = int(screen_height / 2 - window_height / 2)
        position_right = int(screen_width / 2 - window_width / 2)

        # Pencereyi ortala ve boyutlarını ayarla
        self.root.geometry(f'{window_width}x{window_height}+{position_right}+{position_top}')

        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.root)
        self.frame.pack(expand=True)

        self.select_button = tk.Button(self.frame, text="PDF Seçiniz", command=self.select_pdf)
        self.select_button.grid(row=0, column=0, padx=5, pady=10)

        self.file_entry = tk.Entry(self.frame, width=30)
        self.file_entry.grid(row=0, column=1, padx=5, pady=10)

        self.split_button = tk.Button(self.frame, text="PDF Parçalayıcı", command=self.split_pdf)
        self.split_button.grid(row=1, column=0, columnspan=2, pady=10)

        self.add_pdf_button = tk.Button(self.frame, text="PDF Birleştirici", command=self.add_pdfs)
        self.add_pdf_button.grid(row=2, column=0, columnspan=2, pady=10)

    def select_pdf(self):
        self.selected_file = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
        self.file_entry.delete(0, tk.END)  # Önceki metni temizle
        self.file_entry.insert(0, self.selected_file)  # Seçilen dosya adını ekle
        print(f"Selected file: {self.selected_file}")

    def split_pdf(self):
        if not self.selected_file:
            print("No file selected!")
            return

        # Kullanıcıdan sayfa numaralarını veya aralıklarını almak için dialog kullan
        page_numbers_str = simpledialog.askstring("Input", "Enter page numbers or ranges to split (e.g., 1-3,5,7-9):")
        if not page_numbers_str:
            print("No page numbers provided!")
            return

        page_numbers = self.parse_page_ranges(page_numbers_str)
        if not page_numbers:
            print("Invalid page numbers provided!")
            return

        pdf_reader = PdfFileReader(self.selected_file)
        pdf_writer = PdfFileWriter()

        for page_num in page_numbers:
            if page_num < len(pdf_reader.pages):
                pdf_writer.addPage(pdf_reader.getPage(page_num))
            else:
                print(f"Page number {page_num} is out of range!")

        output_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
        if output_path:
            with open(output_path, 'wb') as output_file:
                pdf_writer.write(output_file)
            print(f"Split PDF saved as: {output_path}")
        else:
            print("No output file selected!")

    def parse_page_ranges(self, page_ranges):
        page_numbers = []
        try:
            for part in page_ranges.split(','):
                if '-' in part:
                    start, end = part.split('-')
                    page_numbers.extend(range(int(start) - 1, int(end)))  # 1-index'den 0-index'e dönüşüm
                else:
                    page_numbers.append(int(part) - 1)  # 1-index'den 0-index'e dönüşüm
        except ValueError:
            return None
        return page_numbers

    def add_pdfs(self):
        # Kullanıcıdan eklemek için birden fazla PDF dosyasını seçmesini ister
        pdf_files_to_add = filedialog.askopenfilenames(
            title="Select PDF files to add",
            filetypes=[("PDF files", "*.pdf")],
            initialdir=".",
            multiple=True
        )

        if not pdf_files_to_add:
            print("No files selected!")
            return

        pdf_writer = PdfFileWriter()

        # Eğer `selected_file` varsa, onu ekle
        if hasattr(self, 'selected_file') and self.selected_file:
            pdf_reader_to_add = PdfFileReader(self.selected_file)
            print(f"Adding selected file: {self.selected_file}")
            for page_num in range(pdf_reader_to_add.numPages):
                pdf_writer.addPage(pdf_reader_to_add.getPage(page_num))

        # Seçilen PDF'lerin sayfalarını ekle
        for pdf_path in pdf_files_to_add:
            try:
                pdf_reader_to_add = PdfFileReader(pdf_path)
                print(f"Adding file: {pdf_path}")  # Debug çıktısı
                for page_num in range(pdf_reader_to_add.numPages):
                    pdf_writer.addPage(pdf_reader_to_add.getPage(page_num))
            except Exception as e:
                print(f"Error reading {pdf_path}: {e}")

        output_path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            title="Save PDF with added pages as"
        )

        if output_path:
            try:
                with open(output_path, 'wb') as output_file:
                    pdf_writer.write(output_file)
                print(f"PDF with added pages saved as: {output_path}")
            except Exception as e:
                print(f"Error saving PDF: {e}")
        else:
            print("No output file selected!")

if __name__ == "__main__":
    root = tk.Tk()
    app = PDFEditor(root)
    root.mainloop()
